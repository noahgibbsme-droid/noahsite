import { createClient } from '@supabase/supabase-js';
export function db(){const url=process.env.NEXT_PUBLIC_SUPABASE_URL;const key=process.env.SUPABASE_SERVICE_ROLE_KEY;if(!url||!key)throw new Error('Supabase is not configured yet. Add the environment variables from SETUP.md.');return createClient(url,key,{auth:{persistSession:false}})}
